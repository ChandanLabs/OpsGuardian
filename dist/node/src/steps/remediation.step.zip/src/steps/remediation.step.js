"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/steps/remediation.step.ts
var remediation_step_exports = {};
__export(remediation_step_exports, {
  config: () => config,
  handler: () => handler
});
module.exports = __toCommonJS(remediation_step_exports);

// src/services/mock_infrastructure.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var STATE_FILE = import_path.default.resolve(process.cwd(), "infra_state.json");
var DEFAULT_STATE = {
  healthy: true,
  activeIncidents: [],
  cpuUsage: 12
};
function loadState() {
  try {
    if (!import_fs.default.existsSync(STATE_FILE)) {
      return DEFAULT_STATE;
    }
    return JSON.parse(import_fs.default.readFileSync(STATE_FILE, "utf-8"));
  } catch (e) {
    return DEFAULT_STATE;
  }
}
function saveState(state) {
  import_fs.default.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2));
}
var InfrastructureManager = class {
  static async simulateChaos() {
    console.log("\u{1F525} CHAOS MONKEY: Injecting failure into Redis Connection Pool...");
    const state = loadState();
    state.healthy = false;
    state.activeIncidents.push("REDIS_CONNECTION_TIMEOUT");
    state.cpuUsage = 98;
    saveState(state);
  }
  static async getSystemLogs() {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const state = loadState();
    if (state.healthy) {
      return `
[${timestamp}] INFO: Server listening on port 3000
[${timestamp}] INFO: Database connection active
[${timestamp}] INFO: Job queue processing normally
      `.trim();
    } else {
      return `
[${timestamp}] ERROR: Connection to Redis timed out after 5000ms
[${timestamp}] FATAL: RedisPoolExhaustedError: No available clients
[${timestamp}] WARN: Retrying connection... failed.
[${timestamp}] ERROR: Critical process failure in PID 8923
      `.trim();
    }
  }
  static async healthCheck() {
    const state = loadState();
    if (state.healthy) {
      return { status: 200, message: "OK" };
    } else {
      return { status: 500, message: "SERVICE_UNAVAILABLE" };
    }
  }
  static async executeCommand(command) {
    console.log(`\u{1F4BB} Executing Command on Remote Host: $ ${command}`);
    const state = loadState();
    await new Promise((resolve) => setTimeout(resolve, 2e3));
    if (command.includes("restart redis") || command.includes("flushall") || command.includes("reboot")) {
      state.healthy = true;
      state.activeIncidents = [];
      state.cpuUsage = 15;
      saveState(state);
      return "Command executed successfully. Service 'redis-server' restarted. stdout: OK";
    }
    return `Command '${command}' executed. No specific state change detected.`;
  }
};

// src/steps/remediation.step.ts
var config = {
  name: "ExecuteRemediation",
  type: "event",
  subscribes: ["incident.approved"],
  description: "Executes the approved fix and verifies health",
  emits: ["incident.resolved"]
};
var handler = async (event, { emit, logger, state }) => {
  logger.info("RECEIVED REMEDIATION EVENT", JSON.stringify(event));
  const data = event.data || event;
  const { alertId, analysis } = data;
  const command = analysis.recommendedAction;
  logger.info(`\u{1F6E0}\uFE0F Executing Remediation: ${command}`);
  await InfrastructureManager.executeCommand(command);
  const health = await InfrastructureManager.healthCheck();
  if (health.status === 200) {
    logger.info("\u2705 System Health Verified. Incident Resolved.");
    await state.set(`incident:${alertId}:status`, "RESOLVED");
    await emit({
      topic: "incident.resolved",
      data: { alertId, status: "RESOLVED", health }
    });
  } else {
    logger.error("\u274C Fix failed. System still unhealthy.");
    await state.set(`incident:${alertId}:status`, "FIX_FAILED");
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config,
  handler
});
//# sourceMappingURL=remediation.step.js.map
